import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddnewclientPage } from './addnewclient';

@NgModule({
  declarations: [
    AddnewclientPage,
  ],
  imports: [
    IonicPageModule.forChild(AddnewclientPage),
  ],
})
export class AddnewclientPageModule {}
