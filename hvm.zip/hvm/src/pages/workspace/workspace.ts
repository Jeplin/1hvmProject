import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams ,Events ,MenuController } from 'ionic-angular';
import { Storage } from '@ionic/storage';

import { AllworkspacePage } from '../allworkspace/allworkspace';
import { ClientsPage } from '../clients/clients';
import { SidemenulistProvider } from '../../providers/sidemenulist/sidemenulist';



/**
 * Generated class for the WorkspacePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-workspace',
  templateUrl: 'workspace.html',
})
export class WorkspacePage {
  isCurrent:boolean=false;
  currentWorkspace:string;
  // data:any;

  workspaces:string[];

  constructor(public navCtrl: NavController, public navParams: NavParams,public events:Events,public menuData:SidemenulistProvider, public storage:Storage,public menu:MenuController) {

    this.menu.swipeEnable(true);
    
    // console.log(this.menuData.getData());
    this.workspaces=["1hvm","Workspace1","Workspace2","Another"];
    this.displayUIMethod();
  }
  displayUIMethod(){
    this.isCurrent=false;
    this.getCurrentFromLocal();
  }
  getCurrentFromLocal(){
       console.log("Get Current Local");
        this.storage.get('currentWorkspace').then((cWorkspace) => {
          console.log("Storage :",cWorkspace);
          if(cWorkspace!='' && cWorkspace!=null){
            this.currentWorkspace=cWorkspace;
            this.isCurrent=true;
          }
          else{
            this.isCurrent=false;
          }
        });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad WorkspacePage');
    this.getCurrentFromLocal();
  }

  joinTenantMethod(){
    this.navCtrl.push(AllworkspacePage);
  }

  selectedWorkspaceMethod(current:string){
    let data:any=[{title:'Workspaces',component:WorkspacePage},
                  {title:'Clients',component:ClientsPage}];
    this.menuData.setData(data);
    this.events.publish('sideMenu:menu');

    this.storage.set('currentWorkspace',current);
    this.getCurrentFromLocal();

    this.navCtrl.setRoot(ClientsPage);
  }

}
