import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TaskstabPage } from './taskstab';

@NgModule({
  declarations: [
    TaskstabPage,
  ],
  imports: [
    IonicPageModule.forChild(TaskstabPage),
  ]
})
export class TaskstabPageModule {}
