import { Component } from '@angular/core';
import { NavController,MenuController} from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { LoginPage } from '../login/login';
import { TaskstabPage } from '../taskstab/taskstab';
import { NewsPage } from '../news/news';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  currentClient:string;

  constructor(public navCtrl: NavController,public menu:MenuController,public storage:Storage) {

    console.log("Home");
    
    this.displayUiData();
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad Home');
    this.displayUiData();
  }
  ionViewDidEnter(){
    console.log('ionViewDidEnter Home');
  }

  displayUiData(){
    console.log("Display Home");
    this.storage.get('currentClient').then((cClient) => {
        this.currentClient=cClient;
        console.log("Display Home" ,cClient);
    });
  }

  taskClicked(){
    this.navCtrl.setRoot(TaskstabPage);
  }

  newsClicked(){
    this.navCtrl.setRoot(NewsPage);
  }


}

