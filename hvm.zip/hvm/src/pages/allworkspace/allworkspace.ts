import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the AllworkspacePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-allworkspace',
  templateUrl: 'allworkspace.html',
})
export class AllworkspacePage {

  workspaceData:string[];

  constructor(public navCtrl: NavController, public navParams: NavParams) {

    this.workspaceData=["1HVM-PROD","Gemeente Venlo Test"];

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AllworkspacePage');
  }

}
