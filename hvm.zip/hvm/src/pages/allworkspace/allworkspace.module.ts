import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AllworkspacePage } from './allworkspace';

@NgModule({
  declarations: [
    AllworkspacePage,
  ],
  imports: [
    IonicPageModule.forChild(AllworkspacePage),
  ],
})
export class AllworkspacePageModule {}
