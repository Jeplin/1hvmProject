import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';

import { DatePicker } from '@ionic-native/date-picker';


/**
 * Generated class for the AddTasksPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-add-tasks',
  templateUrl: 'add-tasks.html',
})
export class AddTasksPage {

  currentClient:string;
  isTaskRepeatTxt:string;
  isTaskRepeate:boolean;

  selectedDate:string;

  constructor(public navCtrl: NavController, public navParams: NavParams,public storage:Storage,public datePicker: DatePicker) {
    this.displayUiData();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddTasksPage');
    this.displayUiData();
  }

  displayUiData(){
    console.log("Display Home");
    this.storage.get('currentClient').then((cClient) => {
        this.currentClient=cClient;
        console.log("Display Home" ,cClient);
    });

    this.isTaskRepeatTxt="No";
  }

  datePickerClicked(){
    this.datePicker.show({
      date: new Date(),
      mode: 'date',
      androidTheme: this.datePicker.ANDROID_THEMES.THEME_HOLO_DARK
    }).then(
      date => this.selectedDate=""+date,
      err => console.log('Error occurred while getting date: ', err)
    );
  }

  updateTaskRepeat(){
    console.log(this.isTaskRepeate);
    if(this.isTaskRepeate){
      this.isTaskRepeatTxt="Yes";
    }
    else{
      this.isTaskRepeatTxt="No";
    }
  }

  submitTaskMethod(){

  }

}
