import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { MenuController } from 'ionic-angular/components/app/menu-controller';
import { Storage } from '@ionic/storage';
import { AddTasksPage } from '../add-tasks/add-tasks';

/**
 * Generated class for the ListTaskPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-list-task',
  templateUrl: 'list-task.html',
})
export class ListTaskPage {
  taskList: string[];
  currentClient:string;



  constructor(public navCtrl: NavController, public navParams: NavParams,public storage:Storage) {
    
    this.taskList=["List1","List2","List3","List4"];

    this.displayUiData();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ListTaskPage');
    this.taskList=["List1","List2","List3","List4"];
    this.displayUiData();
  }

  displayUiData(){
    console.log("Display Home");
    this.storage.get('currentClient').then((cClient) => {
        this.currentClient=cClient;
        console.log("Display Home" ,cClient);
    });
  }

  addTask(){
    this.navCtrl.push(AddTasksPage);
  }

}
