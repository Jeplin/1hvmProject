import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams , MenuController ,Events } from 'ionic-angular';

import { Storage } from '@ionic/storage';

import { ForgetpasswordPage } from '../forgetpassword/forgetpassword';
import { RegisterPage } from '../register/register';
import { WorkspacePage } from '../workspace/workspace';
import { SidemenulistProvider } from '../../providers/sidemenulist/sidemenulist';
import { ClientsPage } from '../clients/clients';
import { TaskstabPage } from '../taskstab/taskstab';
import { MenuPage } from '../menu/menu';


/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  showPasswordFlag:boolean;
  isShowPassword:boolean=true;

  // data:any;

  constructor(public navCtrl: NavController, public navParams: NavParams,public menu:MenuController,public menuData:SidemenulistProvider,public events:Events,public storage:Storage) {
    console.log("Login");

    this.mainDisplayMethod();

  }
  mainDisplayMethod(){
    this.isShowPassword=true;

    this.events.publish('sideMenu:menu');
    this.menu.swipeEnable(false);

    this.storage.remove('currentWorkspace').then(()=>{
      console.log("Remove all local data");
    });

    this.storage.remove('currentClient').then(()=>{
      console.log("Remove All Client Data");
    });
    //this.storage.set('currentClient',client);

    let data=[{title: 'Workspaces', component: WorkspacePage}];
    this.menuData.setData(data);

    let secData=[];
    this.menuData.setSecondData(secData);
    this.events.publish('sideMenu:menu');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
    this.mainDisplayMethod();
  }
  ionViewDidEnter(){
    console.log('ionViewDidEnter Login');
  }
  passwordShow(){
    console.log("Div clicked");
    if(this.isShowPassword){
      console.log("CheckBox Clicked :",this.isShowPassword);
      this.isShowPassword=false;
    }
    else{
      console.log("CheckBox Clicked :",this.isShowPassword);
      this.isShowPassword=true;
    }
  }

  loginMethod(){

    //this.navCtrl.setRoot(WorkspacePage);
    this.navCtrl.setRoot(MenuPage);
  }
  registerMethod(){
    this.navCtrl.push(RegisterPage);
  }

  forgetPassMethod(){
    this.navCtrl.push(ForgetpasswordPage);
  }
}
