import { Component, ViewChild } from '@angular/core';
import { Nav, Platform ,Events, IonicPage } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { Storage } from '@ionic/storage';

import { LoginPage } from '../login/login';

import { UserProfilePage } from '../user-profile/user-profile';
import { WorkspacePage } from '../workspace/workspace';

import { AddnewclientPage } from '../addnewclient/addnewclient';
import { InvitefamilyPage } from '../invitefamily/invitefamily';
import { HomePage } from '../home/home';
import { ListTaskPage } from '../list-task/list-task';
import { TaskstabPage } from '../taskstab/taskstab';
import { SidemenulistProvider } from '../../providers/sidemenulist/sidemenulist';

/**
 * Generated class for the MenuPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-menu',
  templateUrl: 'menu.html',
})
export class MenuPage {

  @ViewChild(Nav) nav: Nav;

   rootPage: any = WorkspacePage;
   //rootPage: any = TaskstabPage;
  //rootPage: any = AddnewclientPage;

  firstPages:any;
  secondPages:any;
  // pages: Array<{title: string, component: any}>;

  constructor(public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen,public events: Events,public menuData:SidemenulistProvider,public storage:Storage) {
    this.initializeApp();
    console.log("App");

    
    //this.pages=this.menuData.getData();
    this.sideMenuData();
    this.sideSecMenuData();

    events.subscribe('sideMenu:menu', () =>{
      this.sideMenuData();
      this.sideSecMenuData();
    });
    console.log("Main App Page ",this.firstPages);
  }

  sideMenuData(){
    console.log("App Side Menu Data ");
    this.firstPages=this.menuData.getData();
  }
  sideSecMenuData(){
    this.secondPages=this.menuData.getSecondData();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.statusBar.overlaysWebView(false);
      this.statusBar.backgroundColorByHexString("#002884");
      this.splashScreen.hide();
    });
  }

  openPage(page) {
    console.log("Page :",page);
    console.log("Page Component :",page.component);
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.nav.setRoot(page.component);
  }

  userProfileSetting(){
      this.nav.setRoot(UserProfilePage);
  }

  logoutMethod(){
    // let data:any=[{title:'Workspaces',component:WorkspacePage}];
    // this.menuData.setData(data);

    this.storage.remove('currentWorkspace').then(()=>{
        console.log("All Local data remove");
    });
    this.nav.setRoot(LoginPage);
  }


}
