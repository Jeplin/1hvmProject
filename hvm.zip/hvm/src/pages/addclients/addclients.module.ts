import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddclientsPage } from './addclients';

@NgModule({
  declarations: [
    AddclientsPage,
  ],
  imports: [
    IonicPageModule.forChild(AddclientsPage),
  ],
})
export class AddclientsPageModule {}
