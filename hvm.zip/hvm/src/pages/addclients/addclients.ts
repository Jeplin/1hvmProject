import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { AddnewclientPage } from '../addnewclient/addnewclient';
import { InvitefamilyPage } from '../invitefamily/invitefamily';

/**
 * Generated class for the AddclientsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-addclients',
  templateUrl: 'addclients.html',
})
export class AddclientsPage {

  currentWorkspace: string;
  
  constructor(public navCtrl: NavController, public navParams: NavParams,public storage:Storage) {

    this.getLocalData();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddclientsPage');
    this.getLocalData();
  }

  getLocalData(){
    this.storage.get('currentWorkspace').then((cWorkspace) => {
      this.currentWorkspace=cWorkspace;
    });
  }

  createNewClient(){
    this.navCtrl.push(AddnewclientPage);
  }

  requestAccessMethod(){
    this.navCtrl.push(InvitefamilyPage);
  }

}
