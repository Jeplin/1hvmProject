import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the UserProfilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-user-profile',
  templateUrl: 'user-profile.html',
})
export class UserProfilePage {
  isLanguageData: boolean;
  isPasswordData: boolean;
  isChangeEmail: boolean;
  languages: string[];

 
  isUserData:boolean=false;
  laguageSelect:string;



  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.getLocalData();
  }

  getLocalData(){
    this.isChangeEmail=false;
    this.isUserData=false;
    this.isPasswordData=false;
    this.isLanguageData=false;
    this.laguageSelect="English";
    this.languages=["Dutch","English","Franch","Hindi","Italian"];
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad UserProfilePage');
    this.getLocalData();
  }

  showEmailMethod(){
    if(this.isChangeEmail){
      this.isChangeEmail=false;
    }else{
      this.isChangeEmail=true;

      this.isUserData=false;
      this.isPasswordData=false;
      this.isLanguageData=false;
    }
  }

  showUserDataMethod(){
    if(this.isUserData){
      this.isUserData=false;
    }
    else{
      this.isUserData=true;

      this.isChangeEmail=false;
      this.isPasswordData=false;
      this.isLanguageData=false;
    }
  }

  showPasswordMethod(){
    if(this.isPasswordData){
      this.isPasswordData=false;
    }
    else{
      this.isPasswordData=true;

      this.isChangeEmail=false;
      this.isUserData=false;
      this.isLanguageData=false;
    }
  }

  showLanguageMethod(){
    if(this.isLanguageData){
      this.isLanguageData=false;
    }
    else{
      this.isLanguageData=true;

      this.isChangeEmail=false;
      this.isUserData=false;
      this.isPasswordData=false;
    }
  }

}
