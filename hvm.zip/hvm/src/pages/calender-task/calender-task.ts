import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { AddTasksPage } from '../add-tasks/add-tasks';

/**
 * Generated class for the CalenderTaskPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-calender-task',
  templateUrl: 'calender-task.html',
})
export class CalenderTaskPage {
  currentClient:string;


  constructor(public navCtrl: NavController, public navParams: NavParams,public storage:Storage) {
    this.displayUiData();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CalenderTaskPage');
    this.displayUiData();
  }

  displayUiData(){
    console.log("Display Home");
    this.storage.get('currentClient').then((cClient) => {
        this.currentClient=cClient;
        console.log("Display Home" ,cClient);
    });
  }

  addTask(){
    this.navCtrl.push(AddTasksPage);
  }

  

}
