import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CalenderTaskPage } from './calender-task';

@NgModule({
  declarations: [
    CalenderTaskPage,
  ],
  imports: [
    IonicPageModule.forChild(CalenderTaskPage),
  ],
})
export class CalenderTaskPageModule {}
