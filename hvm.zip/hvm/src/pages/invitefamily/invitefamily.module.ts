import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { InvitefamilyPage } from './invitefamily';

@NgModule({
  declarations: [
    InvitefamilyPage,
  ],
  imports: [
    IonicPageModule.forChild(InvitefamilyPage),
  ],
})
export class InvitefamilyPageModule {}
