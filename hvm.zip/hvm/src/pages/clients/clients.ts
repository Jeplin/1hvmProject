import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams ,Events } from 'ionic-angular';
import { AddclientsPage } from '../addclients/addclients';
import { Storage } from '@ionic/storage';
import { SidemenulistProvider } from '../../providers/sidemenulist/sidemenulist';
import { HomePage } from '../home/home';
import { TaskstabPage } from '../taskstab/taskstab';
import { ClientProfilePage } from '../client-profile/client-profile';
import { SecondmenuProvider } from '../../providers/secondmenu/secondmenu';

/**
 * Generated class for the ClientsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-clients',
  templateUrl: 'clients.html',
})
export class ClientsPage {

  currentWorkspace: string;
  clientData:string[];

  constructor(public navCtrl: NavController, public navParams: NavParams,public storage:Storage,public events:Events,public menuData:SidemenulistProvider,public secondMenu:SecondmenuProvider) {

    this.clientData=["Client 1","Client 2"];

    this.getLocalData();

  }
  getLocalData(){
    //this.clientData=["Client 1","Client 2"];
    console.log("Current Local");
    this.storage.get('currentWorkspace').then((cWorkspace) => {
      this.currentWorkspace=cWorkspace;
      console.log("Current :",this.currentWorkspace);
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ClientsPage');
    this.clientData=["Client 1","Client 2"];
    this.getLocalData();
  }

  addClientsMethod(){
    this.navCtrl.push(AddclientsPage);
  }

  clickedClientMethod(client){
    console.log("Client Clicked");

    let data:any=this.secondMenu.getSecondMenu();

    this.menuData.setSecondData(data);
    this.events.publish('sideMenu:menu');

    this.storage.set('currentClient',client);

    this.navCtrl.setRoot(HomePage);
  }

}
