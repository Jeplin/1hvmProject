import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { IonicStorageModule, Storage } from '@ionic/storage';

import { MyApp } from './app.component';

import { LoginPage } from '../pages/login/login';

import { ForgetpasswordPage } from '../pages/forgetpassword/forgetpassword';

import { RegisterPage } from '../pages/register/register';

import { WorkspacePage } from '../pages/workspace/workspace';

import { AllworkspacePage } from '../pages/allworkspace/allworkspace';

import { ClientsPage } from '../pages/clients/clients';

import { AddclientsPage } from '../pages/addclients/addclients';
import { AddnewclientPage } from '../pages/addnewclient/addnewclient';
import { InvitefamilyPage } from '../pages/invitefamily/invitefamily';

import { HomePage } from '../pages/home/home';

import { UserProfilePage } from '../pages/user-profile/user-profile';



import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { SidemenulistProvider } from '../providers/sidemenulist/sidemenulist';
import { TaskstabPage } from '../pages/taskstab/taskstab';
import { ListTaskPage } from '../pages/list-task/list-task';
import { CalenderTaskPage } from '../pages/calender-task/calender-task';
import { TaskstabPageModule } from '../pages/taskstab/taskstab.module';
import { ListTaskPageModule } from '../pages/list-task/list-task.module';
import { CalenderTaskPageModule } from '../pages/calender-task/calender-task.module';
import { MenuPage } from '../pages/menu/menu';
import { ClientProfilePage } from '../pages/client-profile/client-profile';
import { SecondmenuProvider } from '../providers/secondmenu/secondmenu';
import { AddTasksPage } from '../pages/add-tasks/add-tasks';
import { NewsPage } from '../pages/news/news';

import { DatePicker } from '@ionic-native/date-picker';

@NgModule({
  declarations: [
    MyApp,
    LoginPage,
    RegisterPage,
    ForgetpasswordPage,
    MenuPage,
    WorkspacePage,
    AllworkspacePage,
    ClientsPage,
    AddclientsPage,
    AddnewclientPage,
    InvitefamilyPage,
    HomePage,
    AddTasksPage,
    ClientProfilePage,
    NewsPage,
    UserProfilePage,
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot(),
    TaskstabPageModule,
    ListTaskPageModule,
    CalenderTaskPageModule,
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    LoginPage,
    RegisterPage,
    ForgetpasswordPage,
    MenuPage,
    WorkspacePage,
    AllworkspacePage,
    ClientsPage,
    AddclientsPage,
    AddnewclientPage,
    InvitefamilyPage,
    HomePage,
    AddTasksPage,
    ClientProfilePage,
    NewsPage,
    UserProfilePage,
  ],
  providers: [
    StatusBar,
    DatePicker,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    SidemenulistProvider,
    SecondmenuProvider,
  ]
})
export class AppModule {}
