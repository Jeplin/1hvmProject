
import { Injectable } from '@angular/core';
import { ClientProfilePage } from '../../pages/client-profile/client-profile';
import { TaskstabPage } from '../../pages/taskstab/taskstab';
import { NewsPage } from '../../pages/news/news';

/*
  Generated class for the SecondmenuProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class SecondmenuProvider {

  secondMenuData:any;

  constructor() {
    console.log('Hello SecondmenuProvider Provider');

    this.secondMenuData=[{title:'Client Profile',component:ClientProfilePage,icon:'person'},
    {title:'Team',component:"",icon:'people'},
    {title:'Tasks',component:TaskstabPage,icon:'md-checkbox-outline'},
    {title:'Discussion',component:"",icon:'chatboxes'},
    {title:'Datacards',component:"",icon:'disc'},
    {title:'News',component:NewsPage,icon:'paper'}];

  }

  getSecondMenu(){
    return this.secondMenuData;
  }

}
