import { Injectable } from '@angular/core';
import { WorkspacePage } from '../../pages/workspace/workspace';
import { ClientsPage } from '../../pages/clients/clients';

/*
  Generated class for the SidemenulistProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class SidemenulistProvider {

  data:any;
  secondData:any;
  
  constructor() {
    this.data=[
      { title: 'Workspaces', component: WorkspacePage }
    ];
    this.secondData=[];

  }

  getData(){
    return this.data;
  }

  setData(data:any){
    this.data=data;
  }

  getSecondData(){
    return this.secondData;
  }

  setSecondData(secData:any){
    this.secondData=secData;
  }

}
